// req.user est fourni par le middleware requireAuth (contenu du jeton vérifié)
export const get = (req, res) => {
    res.send(`User: ${req.user}`);
};
