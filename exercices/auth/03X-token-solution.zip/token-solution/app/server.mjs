// ETML
// Auteur : bulle SecDevOps
// Date : 26.03.2024
// Description : point d'entrée pour démarrer le serveur node.js de l'exercice
//               "Authentification" (SOLUTION thématique 03 : jeton JWT)
//

// Librairies et ressources

import express from "express";
import cookieParser from "cookie-parser";
import userRoute from "./routes/User.mjs";
import authRoute from "./routes/Auth.mjs";
import { requireAuth } from "./middleware/requireAuth.mjs";
const app = express();

// Middleware pour la lecture des réponses formatées en json
app.use(express.json());
// Lecture des cookies entrants (req.cookies), nécessaire pour retrouver le jeton
app.use(cookieParser());

// Les routes
// /auth reste public (connexion, inscription, déconnexion) ...
app.use('/auth', authRoute);
// ... /user exige un jeton valide
app.use('/user', requireAuth, userRoute);

// Démarrage du serveur (port 8083 dans le conteneur, publié sur 8091 par docker-compose.yml)
const PORT = Number(process.env.PORT ?? 8083);
app.listen(PORT, () => {
    console.log('Séquence authentification (solution 03), server running on port ' + PORT);
});
