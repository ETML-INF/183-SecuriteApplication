import jwt from "jsonwebtoken";

// Clé secrète HS256 : lue dans l'environnement, jamais écrite dans le code.
// Qui possède cette clé peut fabriquer un jeton valide pour n'importe quel utilisateur.
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    throw new Error("JWT_SECRET manquant (variable d'environnement)");
}

export const TOKEN_COOKIE = 'authToken';
export const TOKEN_TTL_SECONDS = 60 * 60; // 1 h

// Le payload est seulement encodé (base64url), PAS chiffré : rien de secret dedans.
export function signToken(username) {
    return jwt.sign({ sub: username }, JWT_SECRET, {
        algorithm: 'HS256',
        expiresIn: TOKEN_TTL_SECONDS, // claim `exp` : un jeton volé ne reste pas valable indéfiniment
    });
}

// `algorithms` imposé : refuse un jeton `alg: none` ou signé avec un autre algorithme.
// Lève une exception si la signature est fausse ou si le jeton est expiré.
export function verifyToken(token) {
    return jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });
}
