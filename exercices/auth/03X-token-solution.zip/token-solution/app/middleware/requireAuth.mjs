import { TOKEN_COOKIE, verifyToken } from "../utils/jwt.mjs";

// Middleware à placer devant les routes protégées (voir server.mjs), PAS devant /auth :
// sinon il devient impossible de se connecter pour obtenir le jeton.
export const requireAuth = (req, res, next) => {
    // req.cookies est rempli par cookie-parser (server.mjs). Sans lui : undefined.
    const token = req.cookies?.[TOKEN_COOKIE];

    if (!token) {
        return res.status(401).json({ error: "Authentication required" });
    }

    try {
        const payload = verifyToken(token);
        req.user = payload.sub; // disponible pour les routes suivantes
        next();
    } catch (error) {
        // signature invalide, jeton modifié ou expiré
        res.clearCookie(TOKEN_COOKIE);
        return res.status(401).json({ error: "Invalid or expired token" });
    }
};
