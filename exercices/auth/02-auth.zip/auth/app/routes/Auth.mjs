import express from "express";
import { connectToDatabase } from "../utils/dbUtils.mjs";


const router = express.Router();

// Middleware pour la connexion à la base de données
const connectToDatabaseMiddleware = async (req, res, next) => {
  try {
    req.dbConnection = await connectToDatabase();
    // la connexion est fermée une fois la réponse envoyée (sinon une connexion reste ouverte par requête)
    res.on('finish', () => req.dbConnection.end().catch(() => {}));
    next();
  } catch (error) {
    console.error("Error connecting to the database:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};


router.post('/', connectToDatabaseMiddleware, async (req, res) => {
  const { username, password } = req.body;

  // INTENTIONALLY VULNERABLE (A05 Injection): the query is built by string concatenation.
  // Exercise: exploit it, then fix it with a prepared statement (? placeholders).
  const queryString = `SELECT * FROM t_users WHERE useName = '${username}' AND usePassword = '${password}'`; 
  // TODO (étape 4) : se protéger de l'injection, en deux couches complémentaires :
  //   1. validation des entrées : username et password sont-ils bien des chaînes (typeof), non vides,
  //      de longueur raisonnable ? Sinon répondre 400 avant de toucher à la DB.
  //   2. paramètres liés (bind params) : placeholders ? dans la requête et valeurs passées séparément,
  //      avec execute() (requête préparée) plutôt que query() : les données ne sont plus jamais du SQL.
  //   Piège : concaténer ET passer un tableau de valeurs ne protège de rien (relire la ligne ci-dessus).
  //   Vérification : le payload de l'étape 3 doit maintenant échouer.
  //   Variante : adapter la requête pour ne plus comparer le mot de passe en SQL (voir étape 6).
  //   Réf. : https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html#parameterized-queries
  //          https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html#implementing-input-validation
  //          https://sidorares.github.io/node-mysql2/docs/documentation/prepared-statements
  // TODO (étape 6) : ne plus comparer le mot de passe en clair. Idée de déroulement :
  //   1. SELECT du salt et du hash de l'utilisateur (WHERE useName = ?) uniquement
  //   2. le vérifier avec le mot de passe reçu (+ poivre), dans l'application, avec un algorithme LENT :
  //      - recommandé : Argon2id, paquet `argon2` (voir README.md, "Ajouter un paquet npm").
  //        argon2.hash(mdp, { salt, secret }) ; argon2.verify(hash, mdp, { secret }) relit le sel dans le hash.
  //        Le poivre : option `secret` (même valeur pour hash et verify). Sans option `salt`, Argon2 tire le sel lui-même.
  //      - sans dépendance : crypto.scrypt. Là, c'est à toi d'appliquer le poivre (ex. HMAC),
  //        puis de comparer en temps constant (crypto.timingSafeEqual).
  //   Pour l'inscription (ou pour remplir la DB), nouveau sel + hash, puis INSERT du salt et du hash.
  //   Réf. : https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#argon2id (puis #salting, #peppering)
  //          https://github.com/ranisalt/node-argon2#readme
  //          https://nodejs.org/api/crypto.html#cryptoscryptpassword-salt-keylen-options-callback

  try {
    const [rows] = await req.dbConnection.query(queryString, [username, password]);
    if (rows.length > 0) {
      res.status(200).json({ message: "Authentication successful" });
    } else {
      res.status(401).json({ error: "Invalid username or password" });
    }
  } catch (error) {
    console.error("Error authenticating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

export default router;
