import mysql from "mysql2/promise";

// INTENTIONAL (starting state of the exercise): the app connects as root/root.
// Least privilege (dedicated db user) is one of the fixes asked in the exercise.
// TODO (étape 5) : créer dans la DB (script SQL d'initialisation) un utilisateur dédié aux droits
//   minimaux (CREATE USER ... puis GRANT SELECT, INSERT ON db_authentication.t_users ...),
//   et l'utiliser ici. Lire ses identifiants dans process.env plutôt que de les écrire dans le code
//   (variables à déclarer dans la section "environment" de docker-compose.yml).
//   Vérification : un `DROP DATABASE` / `TRUNCATE TABLE` via l'API doit être refusé.
//   Réf. : https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html#creating-secure-permissions
//          https://cheatsheetseries.owasp.org/cheatsheets/Database_Security_Cheat_Sheet.html#storing-database-credentials-securely
//          https://dev.mysql.com/doc/refman/8.4/en/grant.html#grant-table-privileges
const dbConfig = {
  // 'db' dans Docker ; '127.0.0.1' + port publié pour la version locale (app/.env)
  host: process.env.DB_HOST ?? 'db',
  port: Number(process.env.DB_PORT ?? 3306),
  user: 'root',
  password: 'root',
  database: 'db_authentication',
  multipleStatements: true

};


export const connectToDatabase = async () => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log("Connected to the database");
    return connection;
  } catch (error) {
    console.error("Error connecting to the database:", error);
    throw error;
  }
};