// TODO (étape 6) : Math.random() n'est pas un générateur cryptographiquement sûr.
//   Utiliser le module `crypto` de node (ex. randomBytes) pour générer le sel,
//   puis le stocker en DB avec le hash (voir db_authentication.sql).
//   Avec Argon2id (paquet `argon2`), on peut passer ce sel (option `salt`, un Buffer) ou laisser la librairie le gérer.
//   Réf. : https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#salting
//          https://nodejs.org/api/crypto.html#cryptorandombytessize-callback
export function generateSalt(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}