// ETML
// Auteur : bulle SecDevOps
// Date : 26.03.2024
// Description : point d'entrée pour démarrer le serveur node.js de l'exercice
//               "Authentification"
//
//

// Librairies et ressources

import express from "express";
import userRoute from "./routes/User.mjs";
import authRoute from "./routes/Auth.mjs";
import { generateSalt } from './utils/generateSalt.mjs';
const app = express();

// Middleware pour la lecture des réponses formatées en json
app.use(express.json());

// Les routes
app.use('/user', userRoute);
app.use('/auth', authRoute);

// Démarrage du serveur
const PORT = Number(process.env.PORT ?? 8083);
app.listen(PORT, () => {
    console.log('Séquence authentification, server running on port ' + PORT);
    console.log(generateSalt(50));
});