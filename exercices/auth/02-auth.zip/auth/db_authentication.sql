SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS `db_authentication` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `db_authentication`;

-- TODO (étape 6) : ajouter une colonne pour le sel (ex. `useSalt`, valeur aléatoire propre à chaque
--   utilisateur). `usePassword` doit contenir le hash, pas le mot de passe.
--   Algorithme LENT conçu pour les mots de passe, pas SHA-256 seul (trop rapide) :
--   - recommandé : Argon2id (paquet npm `argon2`, voir README.md "Ajouter un paquet npm"),
--     résultat ~100 caractères ($argon2id$v=19$m=...$<sel>$<hash>). Argon2 y range aussi le sel :
--     si tu le laisses tirer le sel lui-même, la colonne `useSalt` devient facultative.
--   - sans dépendance : crypto.scrypt (64 octets en hexa = 128 caractères). Colonne `useSalt` obligatoire.
--   Vérifier que la colonne est assez longue pour le résultat.
--   Le poivre, lui, ne va PAS dans la DB : variable d'environnement de l'application.
--   Réf. : https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#password-hashing-algorithms
--   Mettre à jour l'utilisateur `john` ci-dessous avec un sel et un hash calculé par l'application
--   (comment ? voir les indices de l'exercice 02).
DROP TABLE IF EXISTS `t_users`;
CREATE TABLE `t_users` (
  `idUser` int NOT NULL,
  `useName` varchar(255) NOT NULL,
  `usePassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `t_users` (`idUser`, `useName`, `usePassword`) VALUES
(1, 'john', '1234');


ALTER TABLE `t_users`
  ADD PRIMARY KEY (`idUser`),
  ADD UNIQUE KEY `idx_unique_name` (`useName`);


ALTER TABLE `t_users`
  MODIFY `idUser` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
