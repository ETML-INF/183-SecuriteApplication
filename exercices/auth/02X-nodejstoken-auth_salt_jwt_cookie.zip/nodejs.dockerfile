FROM node:24

RUN npm install -g nodemon
WORKDIR /home/node/app
COPY app/package.json .

RUN npm install
COPY app/ ./ 

EXPOSE 8080
CMD ["nodemon", "server.js"]
