SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS `db_authentication` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `db_authentication`;

-- SOLUTION étape 6 : le mot de passe n'est plus stocké, seulement
--   useSalt     : sel aléatoire propre à chaque utilisateur (crypto.randomBytes, 16 octets en hexa)
--   usePassword : hash, selon l'algorithme choisi dans l'application (utils/hashPassword.mjs) :
--     Argon2id (par défaut) : format PHC, ~97 caractères, $argon2id$v=19$m=19456,t=2,p=1$<sel>$<hash>
--                             (Argon2 y recopie le sel : la colonne useSalt serait optionnelle avec lui seul)
--     scrypt (variante)     : 64 octets en hexa = 128 caractères, le sel n'est QUE dans useSalt
--   varchar(255) accepte les deux : ils peuvent cohabiter dans la table.
-- Le poivre n'est PAS ici : variable d'environnement PEPPER de l'application (docker-compose.yml).
DROP TABLE IF EXISTS `t_users`;
CREATE TABLE `t_users` (
  `idUser` int NOT NULL AUTO_INCREMENT,
  `useName` varchar(255) NOT NULL,
  `useSalt` char(32) NOT NULL,
  `usePassword` varchar(255) NOT NULL,
  PRIMARY KEY (`idUser`),
  UNIQUE KEY `idx_unique_name` (`useName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- john / 1234 : hash calculé une fois par l'application (hashPassword('1234', sel)) avec le poivre
--   du docker-compose.yml, puis copié ici. Changer PEPPER rend ce hash (et tous les autres) invalide.
INSERT INTO `t_users` (`useName`, `useSalt`, `usePassword`) VALUES
('john', '9f2c4e8a1b7d3f6052e1a4c8b9d0e7f3',
 '$argon2id$v=19$m=19456,t=2,p=1$nyxOiht9P2BS4aTIudDn8w$5gdk4AvCMeT/dt1m2zOkl3YveNoz6nrsH0ZpUiMhgDY');

-- SOLUTION étape 5 : moindres privilèges. L'application ne peut que lire et créer des utilisateurs
--   (pas de DROP, TRUNCATE, DELETE, UPDATE, ni accès aux autres bases).
CREATE USER IF NOT EXISTS 'app_user'@'%' IDENTIFIED BY 'app_user_pass';
GRANT SELECT, INSERT ON `db_authentication`.`t_users` TO 'app_user'@'%';

COMMIT;
