# Auth app — SOLUTION thématique 02 (02X)

Même code que le point de départ `auth/`, corrigé (commentaires `SOLUTION étape N`) : compare fichier par fichier. Utilisateur de test : `john` / `1234`.

Hachage : **Argon2id** (paquet `argon2`, déjà dans `package.json`), poivre passé en `secret`, sel généré par l'application et stocké dans `useSalt`. Variante sans dépendance avec `crypto.scrypt` dans `app/utils/hashPassword.mjs` (`hashPasswordScrypt`), même schéma de table. Ports différents : peut tourner en même temps que `auth/`.

## Démarrer

```sh
docker compose up -d
```

La commande rend la main quand MySQL est prêt (quelques secondes de plus au premier lancement : téléchargement des images).

| Service | URL |
|---|---|
| API | http://localhost:8089/user (inscription : `POST /auth/register`) |
| phpMyAdmin | http://localhost:8088 (root / root, ou app_user / app_user_pass pour voir les droits restreints) |
| MySQL (client local : DBeaver, HeidiSQL...) | `127.0.0.1`, port `6033` |

Les ports ne sont ouverts que sur ta machine (`127.0.0.1`), pas sur le réseau de l'école.
Logs de l'application : `docker compose logs -f nodejs`.

## Ajouter un paquet npm (ex. `argon2`, `jsonwebtoken`)

Ajoute le paquet dans `app/package.json`, de la façon que tu préfères :

```sh
docker compose exec nodejs npm install argon2   # dans le conteneur
npm install argon2                              # ou depuis ton PC, dans app/
```

Dès que `package.json` change, l'application redémarre et **le conteneur installe lui-même** les paquets manquants
(`npm install` est relancé à chaque démarrage, voir `app/nodemon.json`). Aucune commande Docker à ajouter.

Bon à savoir : le conteneur utilise son propre `node_modules` (compilé pour Linux, ex. `argon2` contient du code natif).
Un `node_modules` sur ton PC ne sert qu'à l'autocomplétion de ton éditeur : le conteneur ne le voit jamais
(masqué au démarrage, exclu de l'image par `.dockerignore`). Un `npm install` local ne peut donc pas casser le conteneur.
Si `Cannot find module` persiste : `docker compose logs nodejs` (erreur d'installation ?) puis `docker compose restart nodejs`.

## Lancer l'app sur ton PC (option)

Par défaut tout tourne dans Docker. Pour lancer l'app avec ton Node local (debugger de l'éditeur, par exemple),
la base reste dans Docker et l'app s'y connecte par le port publié `6033` :

1. `docker compose stop nodejs` (garde `db` et `phpmyadmin`)
2. décommenter les lignes de `app/.env`
3. `cd app && npm install && npm start` (Node 22.9 ou plus : `node --version`)

L'app répond sur la même URL que dans Docker (port `8089`).
Pour revenir à Docker : arrêter l'app locale (Ctrl+C), puis `docker compose up -d`.
Les valeurs de `app/.env` ne gênent pas le conteneur : `docker-compose.yml` définit les siennes, prioritaires.
Si tu ajoutes une variable dans `docker-compose.yml` (ex. étapes 5 et 6), ajoute-la aussi dans `app/.env` pour la version locale.

## ⚠️ La base est en mémoire (par défaut)

La base de données est **recréée depuis `db_authentication.sql` à chaque démarrage** du conteneur `db` (`up` après un `down`, `restart`, redémarrage du PC).

- Avantage : tu modifies `db_authentication.sql`, puis `docker compose restart db`, et c'est appliqué.
- Conséquence : tout ce qui a été ajouté via l'API ou phpMyAdmin est **perdu** au redémarrage. Ce qui doit rester va dans `db_authentication.sql`.
- Ton **code** (`app/`) n'est jamais concerné : il est sur ton disque.

### Garder les données (option)

Renomme `docker-compose.persist.yml` en `docker-compose.override.yml`, puis `docker compose up -d`.
La base est alors stockée dans un volume Docker et survit aux redémarrages.

Mais `db_authentication.sql` n'est plus rejoué que sur une base **vide** : après une modification du SQL, `docker compose down -v` (efface la base) puis `docker compose up -d`.
