import { randomBytes } from "node:crypto";

// SOLUTION étape 6 : générateur cryptographiquement sûr (Math.random() est prévisible).
// 16 octets aléatoires = 32 caractères hexadécimaux (colonne useSalt), pour Argon2id comme pour scrypt.
export function generateSalt(bytes = 16) {
    return randomBytes(bytes).toString('hex');
}
