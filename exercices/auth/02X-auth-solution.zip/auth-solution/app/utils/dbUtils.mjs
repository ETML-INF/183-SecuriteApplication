import mysql from "mysql2/promise";

// SOLUTION étape 5 : connexion avec l'utilisateur à droits restreints créé dans db_authentication.sql
//   (GRANT SELECT, INSERT sur t_users uniquement). Identifiants lus dans l'environnement
//   (docker-compose.yml), jamais écrits dans le code.
// `multipleStatements` est retiré : il permettait d'enchaîner plusieurs requêtes (`...; DROP DATABASE ...`).
const dbConfig = {
  // 'db' dans Docker ; '127.0.0.1' + port publié pour la version locale (app/.env)
  host: process.env.DB_HOST ?? 'db',
  port: Number(process.env.DB_PORT ?? 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: 'db_authentication',
};

if (!dbConfig.user || !dbConfig.password) {
  throw new Error("DB_USER / DB_PASSWORD manquants (variables d'environnement)");
}

export const connectToDatabase = async () => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log("Connected to the database");
    return connection;
  } catch (error) {
    console.error("Error connecting to the database:", error);
    throw error;
  }
};
