import argon2 from "argon2";
import { createHmac, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scryptAsync = promisify(scrypt);

// Poivre : secret commun à toute l'application, jamais stocké en DB (variable d'environnement).
const PEPPER = process.env.PEPPER;
if (!PEPPER) {
    throw new Error("PEPPER manquant (variable d'environnement)");
}

// SOLUTION étape 6 : sel + poivre + algorithme LENT.
//  - sel : généré par l'application (generateSalt, crypto.randomBytes), propre à chaque utilisateur,
//    stocké en clair dans la colonne useSalt. Deux mots de passe identiques donnent deux hash différents,
//    les rainbow tables deviennent inutiles.
//  - poivre : même valeur pour tous, hors de la DB. Un export de la DB seul ne suffit pas pour tester
//    des mots de passe.
//  - lent (volontairement) : une attaque par force brute coûte cher. SHA-256 seul est trop rapide.
// Deux algorithmes au choix, mêmes entrées (mot de passe, sel), même colonne usePassword :

// 1. Argon2id (recommandé par OWASP), paquet npm `argon2`. Paramètres = minimum OWASP (19 MiB, 2 itérations, 1 thread).
//    Le poivre passe par l'option `secret` d'Argon2, prévue pour ça.
//    Résultat au format PHC (~97 caractères) : $argon2id$v=19$m=19456,t=2,p=1$<sel base64>$<hash base64>
//    Argon2 recopie le sel dans ce résultat. Sans option `salt`, la librairie le tirerait elle-même
//    et la colonne useSalt deviendrait inutile ; ici on le fournit pour garder le même schéma que scrypt.
// Réf. : https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#argon2id
const argon2Options = (salt) => ({
    type: argon2.argon2id,
    memoryCost: 19456, // KiB = 19 MiB
    timeCost: 2,
    parallelism: 1,
    secret: Buffer.from(PEPPER),
    ...(salt && { salt: Buffer.from(salt, 'hex') }),
});

export async function hashPassword(password, salt) {
    return argon2.hash(password, argon2Options(salt));
}

// 2. VARIANTE sans dépendance : scrypt, intégré à node (rien à installer).
//    Pour l'utiliser : remplacer hashPassword par hashPasswordScrypt dans routes/Auth.mjs (/register).
//    Ici, c'est à nous d'appliquer le poivre (HMAC) ; le résultat ne contient que le hash (128 caractères hexa),
//    d'où la colonne useSalt obligatoire. Paramètres OWASP : N=2^17, r=8, p=1 (128 MiB, d'où maxmem).
// Réf. : https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html#scrypt
const SCRYPT_OPTIONS = { N: 2 ** 17, r: 8, p: 1, maxmem: 256 * 1024 * 1024 };

async function scryptHash(password, salt) {
    const peppered = createHmac('sha256', PEPPER).update(password).digest();
    return scryptAsync(peppered, salt, 64, SCRYPT_OPTIONS);
}

export async function hashPasswordScrypt(password, salt) {
    return (await scryptHash(password, salt)).toString('hex');
}

// Vérification : l'algorithme est reconnu au début du hash stocké, les deux formats cohabitent
// dans la même table (c'est aussi comme ça qu'on migre d'un algorithme à un autre).
export async function verifyPassword(password, salt, storedHash) {
    if (storedHash.startsWith('$argon2')) {
        // argon2.verify relit le sel et les paramètres dans le hash ; il faut seulement redonner le poivre.
        return argon2.verify(storedHash, password, { secret: Buffer.from(PEPPER) });
    }
    const computed = await scryptHash(password, salt);
    const stored = Buffer.from(storedHash, 'hex');
    // Comparaison en temps constant : le temps de réponse ne révèle pas combien d'octets sont justes.
    return computed.length === stored.length && timingSafeEqual(computed, stored);
}
