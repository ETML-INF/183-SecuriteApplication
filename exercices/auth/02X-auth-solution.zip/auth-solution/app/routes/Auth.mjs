import express from "express";
import { connectToDatabase } from "../utils/dbUtils.mjs";
import { generateSalt } from "../utils/generateSalt.mjs";
// Argon2id par défaut. Variante scrypt (sans dépendance) : importer hashPasswordScrypt et
// l'utiliser à la place de hashPassword dans /register (verifyPassword reconnaît les deux).
import { hashPassword, verifyPassword } from "../utils/hashPassword.mjs";


const router = express.Router();

// Middleware pour la connexion à la base de données
const connectToDatabaseMiddleware = async (req, res, next) => {
  try {
    req.dbConnection = await connectToDatabase();
    // la connexion est fermée une fois la réponse envoyée (sinon une connexion reste ouverte par requête)
    res.on('finish', () => req.dbConnection.end().catch(() => {}));
    next();
  } catch (error) {
    console.error("Error connecting to the database:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// SOLUTION étape 4, couche 1 : validation des entrées avant de toucher à la DB
const isValidField = (value) => typeof value === 'string' && value.length > 0 && value.length <= 255;

const validateCredentials = (req, res, next) => {
  const { username, password } = req.body ?? {};
  if (!isValidField(username) || !isValidField(password)) {
    return res.status(400).json({ error: "username and password must be non-empty strings (max 255)" });
  }
  next();
};

// Connexion : POST /auth  { "username": "...", "password": "..." }
router.post('/', validateCredentials, connectToDatabaseMiddleware, async (req, res) => {
  const { username, password } = req.body;

  try {
    // SOLUTION étape 4, couche 2 : requête préparée (execute + placeholder ?).
    //   La valeur est envoyée séparément du SQL : elle ne peut plus jamais devenir du code.
    // SOLUTION étape 6 : le mot de passe n'est plus comparé en SQL. On récupère sel + hash,
    //   on recalcule le hash avec le mot de passe reçu, puis on compare dans l'application.
    const [rows] = await req.dbConnection.execute(
      'SELECT useSalt, usePassword FROM t_users WHERE useName = ?',
      [username]
    );

    // Même message que l'utilisateur existe ou non : on ne révèle pas quels comptes existent.
    if (rows.length === 1 && await verifyPassword(password, rows[0].useSalt, rows[0].usePassword)) {
      res.status(200).json({ message: "Authentication successful" });
    } else {
      res.status(401).json({ error: "Invalid username or password" });
    }
  } catch (error) {
    console.error("Error authenticating user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Inscription : POST /auth/register  { "username": "...", "password": "..." }
// Même calcul que pour la connexion, avec un nouveau sel, puis INSERT (autorisé par le GRANT).
router.post('/register', validateCredentials, connectToDatabaseMiddleware, async (req, res) => {
  const { username, password } = req.body;

  try {
    const salt = generateSalt();
    const hash = await hashPassword(password, salt);
    await req.dbConnection.execute(
      'INSERT INTO t_users (useName, useSalt, usePassword) VALUES (?, ?, ?)',
      [username, salt, hash]
    );
    res.status(201).json({ message: "User created" });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: "Username already taken" });
    }
    console.error("Error registering user:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

export default router;
