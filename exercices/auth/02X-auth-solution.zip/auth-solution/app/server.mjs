// ETML
// Auteur : bulle SecDevOps
// Date : 26.03.2024
// Description : point d'entrée pour démarrer le serveur node.js de l'exercice
//               "Authentification" (SOLUTION thématique 02)
//

// Librairies et ressources

import express from "express";
import userRoute from "./routes/User.mjs";
import authRoute from "./routes/Auth.mjs";
const app = express();

// Middleware pour la lecture des réponses formatées en json
app.use(express.json());

// Les routes
// Pas encore de session : /user reste public. Token JWT : thématique 03 (voir 03X-token-solution).
app.use('/user', userRoute);
app.use('/auth', authRoute);

// Démarrage du serveur (port 8083 dans le conteneur, publié sur 8089 par docker-compose.yml)
const PORT = Number(process.env.PORT ?? 8083);
app.listen(PORT, () => {
    console.log('Séquence authentification (solution 02), server running on port ' + PORT);
});
