-- Étape 2 (utilisateurs) : écrire ici les CREATE USER / GRANT (exécuté automatiquement après 2_create_views.sql,
--   seulement sur une base vide).
-- Rejouer les scripts (remise à zéro de la base) : docker compose down -v && docker compose up -d
-- Ne pas enlever : les scripts sont exécutés sans base sélectionnée.
USE db_students;

