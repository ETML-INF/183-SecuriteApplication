-- Étape 2 (vues) : écrire ici les CREATE VIEW ... (exécuté automatiquement, seulement sur une base vide).
-- Rejouer les scripts (remise à zéro de la base) : docker compose down -v && docker compose up -d
-- Ne pas enlever : les scripts sont exécutés sans base sélectionnée.
USE db_students;

