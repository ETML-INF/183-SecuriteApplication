# Vues et procédures stockées (thématique 05)

## Démarrer

```sh
docker compose up -d
```

La commande rend la main quand MySQL est prêt et que les scripts sont exécutés.

| Service | Accès |
|---|---|
| phpMyAdmin | http://localhost:8084 (root / root), base `db_students` |
| MySQL (client local : DBeaver, HeidiSQL, `mysql`...) | `127.0.0.1`, port `6032`, root / root |

Les ports ne sont ouverts que sur ta machine (`127.0.0.1`), pas sur le réseau de l'école.

## Où écrire tes réponses

Les scripts sont dans le dossier `sql/` :

| Script | Contenu | Exécuté au démarrage |
|---|---|---|
| `sql/1_db_student_setup.sql` | base `db_students` et ses données (fourni, ne pas modifier) | oui (déjà monté dans `docker-compose.yml`) |
| `sql/2_create_views.sql` | tes `CREATE VIEW` (et ensuite procédures, triggers) | **à toi de le monter** (énoncé, étape 2) |
| `sql/3_create_users.sql` | tes `CREATE USER` / `GRANT` | **à toi de le monter** (énoncé, étape 2) |

MySQL exécute les fichiers montés dans `/docker-entrypoint-initdb.d/` **par ordre alphabétique** : d'où les préfixes `1_`, `2_`, `3_`.
Tes scripts commencent par `USE db_students;` : garde-le (ils sont exécutés sans base sélectionnée).

Essaie tes requêtes dans la console SQL de phpMyAdmin, puis **recopie ce qui marche dans le script** :
c'est le script qui est demandé (étape 2), et il te permet de tout recréer en une commande.
Les procédures et triggers ont besoin de `DELIMITER $$ ... $$ DELIMITER ;` dans le script.

## La base est conservée (persistante)

Ce que tu fais dans phpMyAdmin (vues, utilisateurs, procédures, données) **reste** après un redémarrage du conteneur ou du PC.

⚠️ En contrepartie, les scripts montés ne sont exécutés **que sur une base vide** (premier démarrage).
Modifier un script ne change donc rien à la base existante.

### Remettre la base à zéro (rejouer les scripts)

```sh
docker compose down -v
docker compose up -d
```

`-v` **efface la base** : tout ce qui n'est pas écrit dans les scripts est perdu. Recopie d'abord ton travail dans `2_` / `3_`.
C'est aussi le bon test final : si tout marche après une remise à zéro, tes scripts sont complets.

### Un script est en erreur

Symptôme : `docker compose up -d` affiche `dependency failed to start ... unhealthy`, ou tes vues n'existent pas.

1. `docker compose logs db` : cherche `ERROR` (numéro de ligne et message).
2. Corrige le script (oubli de `USE db_students;` en tête ? `DELIMITER` manquant pour une procédure ?).
3. **Remise à zéro obligatoire** (`down -v` puis `up -d`) : après l'erreur, la base redémarre à moitié
   initialisée (sans tes vues) et ne rejoue plus les scripts.
